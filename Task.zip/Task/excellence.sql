-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2021 at 12:28 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `excellence`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `Id` int(10) NOT NULL,
  `First_Name` text NOT NULL,
  `Last_Name` text NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `Mobile_Number` bigint(10) NOT NULL,
  `Designation` varchar(300) NOT NULL,
  `Gender` varchar(200) NOT NULL,
  `Hobbies` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`Id`, `First_Name`, `Last_Name`, `Email`, `Date_of_Birth`, `Mobile_Number`, `Designation`, `Gender`, `Hobbies`) VALUES
(1, 'NIKKI', 'SINGH', 'ns123@yahoo.com', '2021-08-25', 8536563767, 'PHP Developer', 'Female', 'Reading'),
(2, 'Nikki', 'Singh', 'ns123@yahoo.com', '2021-08-25', 8564362153, 'Software Developer', 'Female', 'Travelling'),
(3, 'Nikki', 'Singh', 'ns122@yahoo.com', '2021-08-19', 8652464677, 'PHP Web Developer', 'Female', 'Singing'),
(4, 'NIKKI', 'SINGH', 'ns123@gmail.com', '2021-08-26', 8861357126, 'PHP Developer', 'Female', 'Travelling'),
(5, 'Niya', 'Sharma', 'n@gmail.com', '2021-08-12', 9652465461, 'Web Developer', 'Female', 'Dancing'),
(6, 'Sandeep', 'Gupta', 'sg123@gmail.com', '2021-08-03', 9435646576, 'PHP Developer', 'Male', 'Travelling'),
(7, 'Amit', 'Sharma', 'as@rediffmail.com', '2021-08-04', 9654653726, 'Web Designer', 'Male', 'Reading'),
(8, 'Sasha', 'Tiwari', 'st@rediffmail.com', '2021-08-05', 9473265764, 'Web Designer', 'Female', 'Singing'),
(9, 'Sohan', 'Mishra', 'sm@gmail.com', '2021-08-23', 7653246735, 'Software Developer', 'Male', 'Travelling'),
(10, 'Sana', 'Khan', 'sk@gmail.com', '2021-08-06', 7352826487, 'Web Developer', 'Female', 'Singing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
