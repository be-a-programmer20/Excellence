<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<title>Form</title>

	<link rel="stylesheet" type="text/css" href="myFile.css">
</head>

<body>

	<?php

	include 'database.php';

	if(isset($_POST['sbt'])) 
	{
		$first = $_POST['fname'];
		$last = $_POST['lname'];
		$mail = $_POST['email'];
		$date = $_POST['dob'];
		$mobile = $_POST['mob_number'];
		$designation = $_POST['des'];
		$gender = $_POST['g1'];
		$hobbies = $_POST['h1'];

		$sql = "insert into user_info(First_Name, Last_Name, Email, Date_of_Birth, Mobile_Number, Designation, Gender, Hobbies)values('$first','$last','$mail','$date','$mobile','$designation','$gender','$hobbies')";

		if(mysqli_query($connect,$sql))
		{
			echo "<script>alert('Your record inserted successfully!')</script>";
		}
		else
		{
			echo "<script>alert('Your record not inserted! Please try again.')</script>";
		}
	}

	?>

	<center>

		<div class="container">

			<h3><strong>FORM</strong></h3>
			<hr><br/>

			<form method="post" autocomplete="off">

				<div>
					<label for="first_name">First Name: </label>
					<input type="text" name="fname" required>
				</div>

				<div>
					<label for="last_name">Last Name: </label>
					<input type="text" name="lname" required>
				</div>

				<div>
					<label for="email">Email: </label>
					<input type="email" name="email" required>
				</div>

				<div>
					<label for="DOB">Date of Birth: </label>
					<input type="date" name="dob" required>
				</div>

				<div>
					<label for="mobile_no">Telephone/Mobile: </label>
					<input type="text" name="mob_number" required>
				</div>

				<div>
					<label for="designation">Designation: </label>
					<input type="text" name="des" required>
				</div>		
				
				<label for="gender">Gender: </label>
				<input type="radio" name="g1" value="Female">Female
				<input type="radio" name="g1" value="Male">Male
				<input type="radio" name="g1" value="Others">Others
				<br><br>
				

				<label for="hobbies">Hobbies: </label>
				<input type="checkbox" name="h1" value="Reading">Reading
				<input type="checkbox" name="h1" value="Singing">Singing
				<input type="checkbox" name="h1" value="Travelling">Travelling
				<input type="checkbox" name="h1" value="Dancing">Dancing
				<br><br>
				
				<input type="submit" name="sbt" value="SUBMIT" title="Submit your form">
			
		    </form>

		</div>

	</center>
	
</body>

</html>