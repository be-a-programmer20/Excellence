<?php

$connect = new mysqli("localhost", "root", "", "excellence");

if($connect === false)
{
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

?>