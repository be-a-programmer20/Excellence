<?php

include_once 'database.php';

$result = mysqli_query($connect,"SELECT * FROM user_info");

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<title>Showing user details</title>

	<style type="text/css">

	table 
	{
		border-collapse: collapse;
		width: 100%;
	}

	td
	{
		border: 1px solid #dddddd;
		padding: 8px;
	}

	tr:nth-child(even) 
	{
		background-color: lightgrey;
	}

    </style>

</head>

<body>

	<h3 align="center">Displaying User Details</h3>
	<hr><br>

	<?php

	if (mysqli_num_rows($result) > 0) 
	{
	?>

		<table>
			<tr>
				<td><strong>Id</strong></td>
				<td><strong>First Name</strong></td>
				<td><strong>Last Name</strong></td>
				<td><strong>Email</strong></td>
				<td><strong>Date of Birth</strong></td>
				<td><strong>Telephone/Mobile Number</strong></td>
				<td><strong>Designation</strong></td>
				<td><strong>Gender</strong></td>
				<td><strong>Hobbies</strong></td>
			</tr>

			<?php

			$i=0;
			while($row = mysqli_fetch_array($result)) 
			{
			?>

			<tr>
				<td><?php echo $row["Id"]; ?></td>
				<td><?php echo $row["First_Name"]; ?></td>
				<td><?php echo $row["Last_Name"]; ?></td>
				<td><?php echo $row["Email"]; ?></td>
				<td><?php echo $row["Date_of_Birth"]; ?></td>
				<td><?php echo $row["Mobile_Number"]; ?></td>
				<td><?php echo $row["Designation"]; ?></td>
				<td><?php echo $row["Gender"]; ?></td>
				<td><?php echo $row["Hobbies"]; ?></td>
			</tr>

			<?php

			$i++;
		    }
		    ?>
	    </table>

	<?php
	}
	else
	{
		echo "Result Not Found";
	}
	?>

</body>

</html>